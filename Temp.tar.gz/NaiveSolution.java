
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author gmdnko003
 */
public class NaiveSolution {
    
    static int noOfItems; //the number of items in the text file
    static float[] intArrayValues2; //the new array of integer values with median filtering applied
    
    
    public static void naiveMethod(float[] list, int filterNo) { //naive method takes parameters ArrayList and filter size, returns array of values
        //list is the full list of integer values
        //1) create a new array of size filterNo
        int median = (filterNo/2)+1; //the median value
        int low= 0; //index of first element in filter
        int hi = filterNo; //index of last element in filter
        int immutables = (filterNo/2); //the number of variables that will no change given their filters
        System.out.println("no. of immutables is: "+immutables);
        //where to start the counter...
        
        for (int i=0; i<noOfItems; i++){
            if (i<immutables){ //if array index is in the range of the first set of immutable items
                intArrayValues2[i] = list[i];
                //System.out.println(list[i]); //testing for correct output
                //low++;
                //hi++;
            }
            else if(i<(noOfItems-(immutables)) & i>=immutables){ //condition to apply median filtering
                float[] filter = new float[filterNo]; //new interger array of filterable elements 
                int j = 0; //iterator variable for filter array
                for (int k=low; k<hi; k++){
                    filter[j] = list[k];
                    //System.out.println(filter[j]); //prints out each element in the unsorted filter array
                    j++;
                }
                Arrays.sort(filter);
                for (int k = 0; k < filterNo; k++) {
                    //System.out.println(filter[k]); //testing for correct output
                }
                intArrayValues2[i] = (filter[median-1]); //-1 to get the array index
                low++;
                hi++;
            }
            else{
                intArrayValues2[i] = list[i];
                //System.out.println(list[i]); //testing for correct output
            }
            System.out.println("Done "+i+"th iteration, inserted "+intArrayValues2[i]+" !");
        }// now I have a mean filtered array of values called intArrayValues2!!!
        //where to end the counter ...
        
    }
    
    private static void debugPrint(int[] intArrayIndex, float[] arrayValue){
        System.out.println("Debug printing...");
        for (int i=0; i<arrayValue.length; i++){
            System.out.println(intArrayIndex[i]+" : "+arrayValue[i]);
        }
    }
}