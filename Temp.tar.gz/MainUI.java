
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author gmdnko003
 */
public class MainUI {
    static List<String> lineList;
    
    static int filterSize = 3; //the variable filter value
    static int[] intArrayIndex; //the integer indexes
    static float[] intArrayValue; //the integer values array
    
    static boolean j = false; //boolean to find if arrayList is past the first index
    static NaiveSolution ns = new NaiveSolution();
    
    public static void main (String[] args){
        try {
            load("inp1.txt");
            //debugPrint(intArrayIndex, intArrayValue);
            //try{
                ns.naiveMethod(intArrayValue, filterSize);
            //}catch(Exception e){
            //    System.out.println("Failed to compute");
            ///}
            
        } catch (IOException ex) {
            Logger.getLogger(NaiveSolution.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void load(String filename) throws FileNotFoundException, IOException { 
        
        
        String path = System.getProperty("user.dir")+"/"+filename; //to get working file directory in all use case
        //Eg. "/home/g/gmdnko003/NetBeansProjects/HashingAssignment/src/lexicon.txt"
        System.out.println(path);
        int index = 0;
        
//        try (FileReader fileReader = new FileReader(path)) {
//            
//        }
            FileReader fileReader = new FileReader(path);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String inputLine; //each line in the text file
            lineList = new ArrayList<String>(); //each line including the word, word type and defintion is an array element
            while ((inputLine = bufferedReader.readLine()) != null) {
                //System.out.println(inputLine);
                lineList.add(inputLine); //now we have an ArrayList of data inputs
                if (j==true){
                    String[] stringArray = inputLine.split(" ");
                    intArrayIndex[index] = Integer.parseInt(stringArray[0]);
                    //System.out.println(stringArray[0]); //line number
                    intArrayValue[index] = Float.parseFloat(stringArray[1]);
                    //System.out.println(stringArray[1]); //floating point value
                    index++;
                }
                else{
                    intArrayValue = new float[Integer.parseInt(inputLine)];
                    ns.intArrayValues2 = new float[Integer.parseInt(inputLine)];
                    intArrayIndex = new int[Integer.parseInt(inputLine)];
                }
                j= true;
                
                //intArrayIndex.add(Integer.parseInt(stringArray[0])); //add text file index
                //intArrayValue.add(Integer.parseInt(stringArray[1]));
            }
            ns.noOfItems = Integer.parseInt(lineList.get(0));
            System.out.println(lineList.get(0));
        
//        catch(Exception e){
//            System.out.println("File not found!");
//        }
    }
}
